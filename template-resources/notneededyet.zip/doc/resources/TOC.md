Houses the "Core" files, as if there were no theme or brand

More of an implementation guide for installing the theme into a project.

Contains:
    -js used in building
    - package list
    - guide for bugs
    - policy for contributing
    - a library of
        suggested plugins
        resources for further learning
        links to 3rd party
        coding cheatsheets
    - roadmap
