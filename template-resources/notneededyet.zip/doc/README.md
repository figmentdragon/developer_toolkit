History of brand/theme - Changelog

Identification of the brand/theme and its fair-rights usage
    - Styleguide

Toolkit Guide
