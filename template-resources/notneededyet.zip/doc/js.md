[HTML5 Boilerplate homepage](https://html5boilerplate.com/) | [Documentation
table of contents](TOC.md)

# The JavaScript

Information about the default JavaScript included in the project.

## app.js

This file can be used to contain or reference your site/app JavaScript code. If
you're working on something more advanced you might replace this file entirely.
That's cool.

## vendor

This directory can be used to contain all 3rd party library code.

Our custom build of the Modernizr library is included by
default. You may wish to create your own [custom Modernizr build with the online
builder](https://modernizr.com/download/) or [command line
tool](https://modernizr.com/docs#command-line-config).
