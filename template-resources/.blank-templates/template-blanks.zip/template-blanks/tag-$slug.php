<?php
/**
 * The template for displaying tag-$slug posts.
 *
 * @package WordPress
 * @subpackage theme_name
 * @since theme_version
 */
