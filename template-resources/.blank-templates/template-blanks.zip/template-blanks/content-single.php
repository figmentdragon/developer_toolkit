<?php
/**
 * The template for displaying single content
 *
 * @package WordPress
 * @subpackage theme_name
 * @since theme_version
 */

	