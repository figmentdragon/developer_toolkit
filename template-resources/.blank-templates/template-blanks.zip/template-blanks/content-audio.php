<?php
/**
 * The template for displaying posts in the Audio Post Format on index and archive pages
 *
 * Learn more: http://codex.wordpress.org/Post_Formats
 *
 * @package WordPress
 * @subpackage theme_name
 * @since theme_version
 */

	
