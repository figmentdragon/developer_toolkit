<?php
/**
 * The template for displaying category-$slug pages
 *
 * @package WordPress
 * @subpackage theme_name
 * @since theme_version
 */
