<?php
/**
 * The template for displaying Author-$nicename pages.
 *
 * @package WordPress
 * @subpackage theme_name
 * @since theme_version
 */

