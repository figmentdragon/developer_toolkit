<?php
/**
 * The Template for displaying all single posts.
 *
 * @package WordPress
 * @subpackage theme_name
 * @since theme_version
 */
