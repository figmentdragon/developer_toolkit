<?php
/**
 * The template for displaying default taxonomy posts.
 *
 * @package WordPress
 * @subpackage theme_name
 * @since theme_version
 */
