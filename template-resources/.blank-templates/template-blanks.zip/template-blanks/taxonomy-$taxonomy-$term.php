<?php
/**
 * The template for displaying taxonomy-$taxonomy-$term posts.
 *
 * @package WordPress
 * @subpackage theme_name
 * @since theme_version
 */
