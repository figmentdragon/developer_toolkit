<?php
/**
 * The template for displaying category-$id pages
 * 
 * @package WordPress
 * @subpackage theme_name
 * @since theme_version
 */
