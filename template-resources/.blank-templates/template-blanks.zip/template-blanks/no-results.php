<?php
/**
 * The template no result pages
 *
 * @package WordPress
 * @subpackage theme_name
 * @since theme_version
 */
