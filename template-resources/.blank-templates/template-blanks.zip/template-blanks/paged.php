<?php
/**
 * The template for displaying paged pages.
 * 
 * Learn more: http://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage theme_name
 * @since theme_version
 */

