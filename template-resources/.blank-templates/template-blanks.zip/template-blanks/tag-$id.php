<?php
/**
 * The template for displaying tag-$id posts.
 *
 * @package WordPress
 * @subpackage theme_name
 * @since theme_version
 */
