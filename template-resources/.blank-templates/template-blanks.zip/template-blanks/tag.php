<?php
/**
 * The template for displaying all tag posts.
 *
 * @package WordPress
 * @subpackage theme_name
 * @since theme_version
 */
