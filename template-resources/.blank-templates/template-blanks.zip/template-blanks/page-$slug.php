<?php
/**
 * The template for displaying content based on pages-$slug.
 *
 * @package WordPress
 * @subpackage theme_name
 * @since theme_version
 */
