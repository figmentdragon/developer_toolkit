<?php
/**
 * The template for displaying Attachment pages.
 *
 * @package WordPress
 * @subpackage theme_name
 * @since theme_version
 */

