<?php
/**
 * The Header for our theme.
 *
 * @package WordPress
 * @subpackage theme_name
 * @since theme_version
 */
?><!DOCTYPE html>