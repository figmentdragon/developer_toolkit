<?php
/**
 * The template for displaying an attachements loop
 *
 * @package WordPress
 * @subpackage theme_name
 * @since theme_version
 */
