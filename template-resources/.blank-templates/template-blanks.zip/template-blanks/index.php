<?php
/**
 * The main template file.
 *
 * @package WordPress
 * @subpackage theme_name
 * @since theme_version
 */