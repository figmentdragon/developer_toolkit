<?php
/**
 * The template for displaying Search Results pages.
 *
 * @package WordPress
 * @subpackage theme_name
 * @since theme_version
 */


