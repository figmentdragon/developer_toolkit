<?php
/**
 * The template for displaying image attachments.
 *
 * @package WordPress
 * @subpackage theme_name
 * @since theme_version
 */
