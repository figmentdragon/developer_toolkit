<?php
/**
 * The Footer widget areas.
 *
 * @package WordPress
 * @subpackage theme_name
 * @since theme_version
 */


