<?php
/**
 * The Sidebar containing the main widget area.
 *
 * @package WordPress
 * @subpackage theme_name
 * @since theme_version
 */
