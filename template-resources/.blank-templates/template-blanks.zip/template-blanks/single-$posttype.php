<?php
/**
 * The template for displaying all single-$posttype content.
 *
 * @package WordPress
 * @subpackage theme_name
 * @since theme_version
 */
