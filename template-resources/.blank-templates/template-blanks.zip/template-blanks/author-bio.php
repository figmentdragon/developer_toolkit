<?php
/**
 * The template for displaying Author Bio Archive pages.
 *
 * @package WordPress
 * @subpackage theme_name
 * @since theme_version
 */

