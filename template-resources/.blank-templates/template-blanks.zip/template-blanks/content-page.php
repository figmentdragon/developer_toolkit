<?php
/**
 * The template used for displaying page content in page.php
 *
 * @package WordPress
 * @subpackage theme_name
 * @since theme_version
 */