<?php
/**
 * The template for displaying Author-$id pages.
 *
 * @package WordPress
 * @subpackage theme_name
 * @since theme_version
 */

