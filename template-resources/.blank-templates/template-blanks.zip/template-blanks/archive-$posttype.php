<?php
/**
 * The template for displaying Archive-$posttype pages.
 *
 * @package WordPress
 * @subpackage theme_name
 * @since theme_version
 */

