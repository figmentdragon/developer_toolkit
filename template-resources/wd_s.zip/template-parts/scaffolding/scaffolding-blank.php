<?php
/**
 * The template used for displaying X in the scaffolding library.
 *
 * @package _s
 */

?>

<section class="section-scaffolding">
	<h2 class="scaffolding-heading"><?php esc_html_e( 'X', '_s' ); ?></h2>
</section>
