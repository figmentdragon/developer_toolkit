/**
 * Template JS
 *
 * JS for WordPress template files.
 * See https://developer.wordpress.org/themes/basics/template-files/.
 */

// import './template-name';
