/**
 * Global JS
 *
 * Import JS that applies globally.
 */

import './js-enabled';
import './window-ready';
